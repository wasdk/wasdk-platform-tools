var Binaryen = function(Module){
