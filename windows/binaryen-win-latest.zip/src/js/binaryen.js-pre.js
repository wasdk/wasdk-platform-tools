var Binaryen = function(Module){
